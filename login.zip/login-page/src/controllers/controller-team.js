module.exports ={
    team(req,res){
        res.render("team",{
            url: 'http://localhost:8000/',
            userName: req.session.username,
        });
    }
}