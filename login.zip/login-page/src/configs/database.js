module.exports = {
    multipleStatements : true,
    host : 'localhost',
    user : 'tes',
    password : 'rahasia',
    database : 'db_node_login'
};