module.exports = {
    multipleStatements : true,
    host : 'sql308.epizy.com',
    user : 'epiz_33467874',
    password : 'zxcvb6545',
    database : 'epiz_33467874_db_node_login'
};